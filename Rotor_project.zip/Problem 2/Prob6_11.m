clear all;
clc;
syms If Im L1 L2 L3 G  D1 D2 D3 n1 n2 w;
J1=pi*D1^4/32 ;
J2=pi*D2^4/32 ;
J3=pi*D3^4/32 ;
K1=(G*J1/L1);
K2=(G*J2/L2);
K3=(G*J3/L3);
P1=[1 0;-w^2*If 1];
P2=[1 0;-w^2*Im 1];
F1=[1 1/K1;0 1];
F2=[1 1/K2;0 1];
F3=[1 1/K3;0 1];
g1=[1/n1 0;0 n1];
g2=[1/n2 0;0 n2];
v=(P1*F1*g1*F2*g2*F3*P2);
disp(v);

V=subs(v,{G,If,Im,L1,L2,L3,D1,D2,D3,n1,n2},{0.8*10^11,0.04,0.01,0.2,0.4,0.2,0.01,0.012,0.015,4,3});
disp(V);
y=V(2);
disp(vpa(solve(y,w)));

