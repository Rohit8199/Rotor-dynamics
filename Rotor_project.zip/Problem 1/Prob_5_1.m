clear all;
clc;
syms w v;
D= 0.02;
L= 0.2;
E= 2.1*10^11
m= 5
I= pi*(D^4)/64;
a11= (L^3)/(3*I*E);
a12= (L^2)/(2*I*E);
a21= (L^2)/(2*I*E);
a22= (L)/(I*E);
Id= 0.5*m*(D/2)^2;
U= (Id*a22)/(m*a11);
X= a12^2/(a11*a22);
f= v^4 - 2*w*v^3 + (U+1)*v^2/(U*(X-1)) -2*w*v/(X-1) - 1/(U*(X-1));

% for forward whirl
F1= subs(f, v, w);
disp(F1);
y = solve(F1);
yf1=y(2);
yf2=y(4);
wf1= yf1/sqrt(a11*m);
wf2= yf2/sqrt(a11*m);
wf1=vpa(wf1)
wf2=vpa(wf2)

% for backward whirl
F2= subs(f, v, -w);
y = solve(F2);
yb1=y(2);
yb2=y(4);
wb1= yb1/sqrt(a11*m);
wb2= yb2/sqrt(a11*m);
wb1=vpa(wb1)
wb2=vpa(wb2)


