clear all;
clc;
syms I1 I2 L1 L2 L3 G D  w;
%the transfer matrix we get after paper work
J=(pi*D^4)/32;
kt1=(G*J/L1);
kt2=(G*J/L2);
kt3=(G*J/L3);
F1=[1 1/kt1;0 1];
F2=[1 1/kt2;0 1];
F3=[1 1/kt3;0 1];
P1=[1 0;-w^2*I2 1];
P2=[1 0;-w^2*I1 1];
v=F1*P1*F2*P2*F3;
V=subs(v,{I1,I2,L1,L2,L3,G,D},{0.0008,0.002,(50*10^-3),(75*10^-3),(50*10^-3),.8*10^11,10*10^-3});
disp(V);
%applying the boundary condition of the matrix
Y=V(2);
disp(vpa(solve(Y,w)));