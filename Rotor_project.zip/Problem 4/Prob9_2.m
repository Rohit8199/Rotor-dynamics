%aassignment 5
%date of birth month is November

%influence coefficient matrix method

clc
clear all
syms l ei m1 m2 w

%influence coefficient matrix
a11=l^3/(3*ei);
a12=((0.5*l)^3/(3*ei))+(0.5*l)^3/(2*ei);
a21=a12;
a22=(0.5*l)^3/(3*ei);

%substitution
A=[a11*m1 a12*m2;a21*m1 a22*m2];
A=subs(A,{l,ei,m1,m2},{0.3,2*10^6,10,8});
M=A-(1/w^2)*eye(2);
M=vpa(M);
M=det(M);

%frequency
frequency=solve(M,w);
frequency=frequency(3:4)