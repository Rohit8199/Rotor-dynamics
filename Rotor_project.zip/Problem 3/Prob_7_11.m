G=0.8*10^11;
rho=7800;
%element 1
Ip=0.01;
D1=0.01;
J1=pi*D1^4/32 ;
L1=0.6;
M1=(rho*J1*L1)/6*[2 1;1 2];
M1=M1+[Ip 0;0 0];
K1=(G*J1/L1)*[1 -1;-1 1];
%element 2
D2=0.03;
J2=pi*D2^4/32 ;
L2=0.4;
M2=(rho*J2*L2)/6*[2 1;1 2];
K2=(G*J2/L2)*[1 -1;-1 1];

%global matrix
M=zeros(3,3);
M(1:2,1:2)=M1;
M(2:3,2:3)=M(2:3,2:3)+M2;

K=zeros(3,3);
K(1:2,1:2)=K1;
K(2:3,2:3)=K(2:3,2:3)+K2;

%after applying boundary condition 
M=M(1:2,1:2);
K=K(1:2,1:2);

%solution 
D=(inv(M))*K;
w_FEM=sqrt(eig(D))

