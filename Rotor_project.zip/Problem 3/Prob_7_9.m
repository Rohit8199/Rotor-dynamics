clear all;
clc;
syms w ;
IP1=24/9.81 ;
Ig1=0;  % neglect gear inertia
Ip2=10/9.81;
Ig2=0;  % neglect gear inertia
l1=0.75;
l2=1;
d1=0.05;
d2=0.04;
n=2;
G=0.8*10^11;
j1=pi*(d1^4)/32;
disp(j1);
j2=pi*(d2^4)/32;
kt1=G*j1/l1;
kt2=G*j2/l2;
 %element 1
 m1=[IP1 0;0 0];
 k1=kt1*[1 -1;-1 1];

 %element 2
  m2=[0 0;0 Ip2];
 k2=kt2*[1/n^2 -1/n;-1/n 1];
 
 %global matrix
 M=zeros(3,3);
 M(1:2,1:2)=m1;
 M(2:3,2:3)=M(2:3,2:3)+m2;

 K=zeros(3,3);
 K(1:2,1:2)=k1;
 K(2:3,2:3)=K(2:3,2:3)+k2;


 M=(-w^2)*M;
 A=zeros(3,3);
 A= M+K;
 disp(A);

 %solution 
 B= det(A);
 W= solve(B==0);
 disp(vpa(W));
 
 %disp(vpa(solve(A,w)));






 