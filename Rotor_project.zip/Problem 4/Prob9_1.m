% we divide the system into two element 
% we assume value of E
E=2.1*10^11;
syms w;
% given disk properties:
m=5;
Id=0.02;
% element 1
a=0.3;
d=0.01; % shaft diametre
Ixx=(E*pi*d^4)/(64*a^3);

M1=[m 0 0 0;0 Id 0 0;0 0 0 0;0 0 0 0];
K1=[12 -6*a -12 -6*a;-6*a 4*a^2 6*a 2*a^2;-12 6*a 12 6*a;-6*a 2*a^2 6*a 4*a^2]*Ixx;

% element 2
a=0.7;
M2=zeros(4,4);
K2=[12 -6*a -12 -6*a;-6*a 4*a^2 6*a 2*a^2;-12 6*a 12 6*a;-6*a 2*a^2 6*a 4*a^2]*Ixx;

%global matrix
M=zeros(6,6);
M(1:4,1:4)=M1;

K=zeros(6,6);
K(1:4,1:4)=K1;
K(3:6,3:6)=K(1:4,1:4)+K2;

% after applying the boundary condition 
M_red=zeros(3,3);
M_red=M([1:2,4],[1:2,4]);
disp(M_red);

K_red=zeros(3,3);
K_red=K([1:2,4],[1:2,4]);
disp(K_red);

A= zeros(3,3);
A= A+ K_red-(M_red*w^2);

 B= det(A);
 W= solve(B==0);
 disp(vpa(W));
 