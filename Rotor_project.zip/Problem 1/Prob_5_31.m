clear all
clc
syms a11 a12 a21 a22 w m e i u a_bar l id a b v d
m=2;
id=0.01;
a=0.6;
b=0.4;
l=1;
e=2.1*10^11;
d=0.015;
i=pi*d^4/64;
a11=5.55*10^-3;
a22=-5.55*10^-3;
a12=5.55*10^-3;
a21=a12;
u=id*a22/(m*a11);
a_bar=a12^2/(a22*a11);
f=v^4-2*w*v^3+(u+1)*v^2/(u*(a_bar-1))-2*w*v/(a_bar-1)-1/(u*(a_bar-1));
f1=subs(f,v,w);
y=solve(f1);
y_f1=y(2);
y_f2=y(4);
w_f1=y_f1/sqrt(a11*m);
w_f2=y_f2/sqrt(a11*m);
w_f1=vpa(w_f1)
w_f2=vpa(w_f2)
f2=subs(f,v,-w);
y1=solve(f2);
y_b1=y1(2);
y_b2=y1(4);
w_b1=y_b1/sqrt(a11*m);
w_b2=y_b2/sqrt(a11*m);
w_b1=vpa(w_b1)
w_b2=vpa(w_b2)

