syms ip l1 l2 d1 d2 G w_TMM;
j1=pi*d1^4/32 ;
j2=pi*d2^4/32; 
kt1=(G*j1/l1);
kt2=(G*j2/l2);
F1=[1 1/kt1;0 1];
F2=[1 1/kt2;0 1];
P1=[1 0;-w_TMM^2*ip 1];
u= F1*F2*P1;


U= subs(u,{ip, d1, d2, G, l1, l2}, {0.01, 0.03, 0.01, 0.8*10^11, 0.4, 0.6});
disp(U);
%after applying boundary condition 
y= U(1);
disp(vpa(solve(y,w_TMM)))
